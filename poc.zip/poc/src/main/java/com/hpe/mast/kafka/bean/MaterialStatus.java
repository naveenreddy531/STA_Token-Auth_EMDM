package com.hpe.mast.kafka.bean;

public class MaterialStatus {
	
	public String SourceSystemCode;
	public String CrossPlantMaterialStatusCode;
	public String CrossPlantMaterialStatusDescription;
	public String getSourceSystemCode() {
		return SourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		SourceSystemCode = sourceSystemCode;
	}
	public String getCrossPlantMaterialStatusCode() {
		return CrossPlantMaterialStatusCode;
	}
	public void setCrossPlantMaterialStatusCode(String crossPlantMaterialStatusCode) {
		CrossPlantMaterialStatusCode = crossPlantMaterialStatusCode;
	}
	public String getCrossPlantMaterialStatusDescription() {
		return CrossPlantMaterialStatusDescription;
	}
	public void setCrossPlantMaterialStatusDescription(String crossPlantMaterialStatusDescription) {
		CrossPlantMaterialStatusDescription = crossPlantMaterialStatusDescription;
	}
	
	
	
	

}
