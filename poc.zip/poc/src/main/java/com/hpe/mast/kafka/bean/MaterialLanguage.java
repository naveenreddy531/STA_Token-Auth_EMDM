package com.hpe.mast.kafka.bean;

public class MaterialLanguage {
	 
	public String SourceSystemCode;
	public String MaterialIdentifier;
	public String ISOLanguageCode;
	public String MaterialDescription;
	//private String basicDataText;
	public String getSourceSystemCode() {
		return SourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		SourceSystemCode = sourceSystemCode;
	}
	public String getMaterialIdentifier() {
		return MaterialIdentifier;
	}
	public void setMaterialIdentifier(String materialIdentifier) {
		MaterialIdentifier = materialIdentifier;
	}
	public String getISOLanguageCode() {
		return ISOLanguageCode;
	}
	public void setISOLanguageCode(String iSOLanguageCode) {
		ISOLanguageCode = iSOLanguageCode;
	}
	public String getMaterialDescription() {
		return MaterialDescription;
	}
	public void setMaterialDescription(String materialDescription) {
		MaterialDescription = materialDescription;
	}
	
	

}
