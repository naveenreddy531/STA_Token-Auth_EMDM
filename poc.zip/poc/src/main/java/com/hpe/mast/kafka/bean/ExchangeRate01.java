package com.hpe.mast.kafka.bean;

import java.util.List;

public class ExchangeRate01 {

	public EXCHANGE_RATE01 EXCHANGE_RATE01;

	public EXCHANGE_RATE01 getEXCHANGE_RATE01() {
		return EXCHANGE_RATE01;
	}

	public void setEXCHANGE_RATE01(EXCHANGE_RATE01 eXCHANGE_RATE01) {
		EXCHANGE_RATE01 = eXCHANGE_RATE01;
	}

	public class EXCHANGE_RATE01 {

		public IDOC IDOC;

		public IDOC getIDOC() {
			return IDOC;
		}

		public void setIDOC(IDOC iDOC) {
			IDOC = iDOC;
		}

		public class IDOC {

			public E1EXCHANGE_RATE E1EXCHANGE_RATE;

			public E1EXCHANGE_RATE getE1EXCHANGE_RATE() {
				return E1EXCHANGE_RATE;
			}

			public void setE1EXCHANGE_RATE(E1EXCHANGE_RATE e1exchange_RATE) {
				E1EXCHANGE_RATE = e1exchange_RATE;
			}

			public class E1EXCHANGE_RATE {

				public Object E1BP1093_0;

				public Object getE1BP1093_0() {
					return E1BP1093_0;
				}

				public void setE1BP1093_0(Object e1bp1093_0) {
					E1BP1093_0 = e1bp1093_0;
				}


			}

		}

	}

}
