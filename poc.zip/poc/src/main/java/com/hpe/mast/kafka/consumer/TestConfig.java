/*package com.hpe.mast.kafka.consumer;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.hpe.mast.kafka.bean.ExchangeRate01;
import com.hpe.mast.kafka.bean.MaterialMaster;
import com.hpe.mast.kafka.bean.PricingMaster;

@EnableKafka
@Configuration

@PropertySource({"classpath:config/mast/dao.properties" })
public class TestConfig {
	
	
static final Logger logger = Logger.getLogger(TestConfig.class);
	
	@Value("${mast.db.driverName}")
	private String driverName;
	@Value("${mast.db.url}")
	private String mastDBUrl;
	@Value("${mast.db.username}")
	private String userName;
	@Value("${mast.db.password}")
	private String password;
	
	@Bean
	public DataSource myMastDataSource() throws Exception {
		logger.info("inside data source initializer");
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverName);
		dataSource.setUrl(mastDBUrl);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		//dataSource.getConnection().setAutoCommit(false);
		//dataSource.setEnableAutoCommitOnReturn(false);
		logger.info("Data source");
		logger.info(dataSource.toString());
		return dataSource;
	}
	
	
	@Bean
    public Map<String, Object> consumerConfigs() {
        Map<String, Object> props = new HashMap<String, Object>();
        ClassLoader classLoader = getClass().getClassLoader();
    	File trustStoreFile = new File(classLoader.getResource("mpaas_kfk_truststore.jks").getFile());
    	File keyStoreFile = new File(classLoader.getResource("mpaas_kfk_keystore.jks").getFile());
      //  props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "hc4t00601.itcs.hpecorp.net:9443,hc4t00602.itcs.hpecorp.net:9443,hc4t00603.itcs.hpecorp.net:9443,hc4t00604.itcs.hpecorp.net:9443,hc4t00605.itcs.hpecorp.net:9443");
      props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "hc4t02271.itcs.hpecorp.net:9443,hc4t02272.itcs.hpecorp.net:9443,hc4t02273.itcs.hpecorp.net:9443,hc4t02274.itcs.hpecorp.net:9443,hc4t02275.itcs.hpecorp.net:9443,hc4t02276.itcs.hpecorp.net:9443");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "S4-MAST_hpit-ifsl_group");//"NGQ_hpit-ifsl_group");
        //props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,trustStoreFile.getPath());
        //props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, "C:\\Users\\du20013955\\Desktop\\mpaas_kfk_truststore.jks");
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "wipro@123");
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "wipro@123");
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,keyStoreFile.getPath());
        //props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, "C:\\Users\\du20013955\\Desktop\\mpaas_kfk_keystore.jks ");
        props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "wipro@123");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false); 
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        return props;
    }
	
	 @Bean
	    public ConsumerFactory<String, String> consumerFactory() {
	        return new DefaultKafkaConsumerFactory<String, String>(consumerConfigs());
	    }

	    @Bean
	    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory() {
	        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<String, String>();
	        factory.setConsumerFactory(consumerFactory());
	        factory.setBatchListener(true);
	       // factory.getContainerProperties().setGenericErrorHandler(new BatchLoggingErrorHandler());
	        factory.getContainerProperties().setAckMode(AbstractMessageListenerContainer.AckMode.MANUAL_IMMEDIATE);
	        factory.getContainerProperties().setSyncCommits(true);
	        return factory;
	    }

}
*/