//package com.hpe.mast.kafka.bean;

/*public class ProductHierarchy {
	 private String SourceSystemCode;
	 private String ProductHierarchyCode;
	 private String ProductHierarchyDescription;
	 private float ProductHierarchyLevelNumber;
	 private String ProductTypeCode;
	 private String ProductTypeDescription;
	 private String ProductCategoryCode;
	 private String ProductCategoryDescription;
	 private String ProductSubCategoryCode;
	 private String ProductSubCategoryDescription;
	 private String ProductFamilyCode;
	 private String ProductFamilyDescription;
	 private String ProductSeriesCode;
	 private String ProductSeriesDescription;
	 private String ProductModelCode;
	 private String ProductModelDescription;


	 // Getter Methods 

	 public String getSourceSystemCode() {
	  return SourceSystemCode;
	 }

	 public String getProductHierarchyCode() {
	  return ProductHierarchyCode;
	 }

	 public String getProductHierarchyDescription() {
	  return ProductHierarchyDescription;
	 }

	 public float getProductHierarchyLevelNumber() {
	  return ProductHierarchyLevelNumber;
	 }

	 public String getProductTypeCode() {
	  return ProductTypeCode;
	 }

	 public String getProductTypeDescription() {
	  return ProductTypeDescription;
	 }

	 public String getProductCategoryCode() {
	  return ProductCategoryCode;
	 }

	 public String getProductCategoryDescription() {
	  return ProductCategoryDescription;
	 }

	 public String getProductSubCategoryCode() {
	  return ProductSubCategoryCode;
	 }

	 public String getProductSubCategoryDescription() {
	  return ProductSubCategoryDescription;
	 }

	 public String getProductFamilyCode() {
	  return ProductFamilyCode;
	 }

	 public String getProductFamilyDescription() {
	  return ProductFamilyDescription;
	 }

	 public String getProductSeriesCode() {
	  return ProductSeriesCode;
	 }

	 public String getProductSeriesDescription() {
	  return ProductSeriesDescription;
	 }

	 public String getProductModelCode() {
	  return ProductModelCode;
	 }

	 public String getProductModelDescription() {
	  return ProductModelDescription;
	 }

	 // Setter Methods 

	 public void setSourceSystemCode(String SourceSystemCode) {
	  this.SourceSystemCode = SourceSystemCode;
	 }

	 public void setProductHierarchyCode(String ProductHierarchyCode) {
	  this.ProductHierarchyCode = ProductHierarchyCode;
	 }

	 public void setProductHierarchyDescription(String ProductHierarchyDescription) {
	  this.ProductHierarchyDescription = ProductHierarchyDescription;
	 }

	 public void setProductHierarchyLevelNumber(float ProductHierarchyLevelNumber) {
	  this.ProductHierarchyLevelNumber = ProductHierarchyLevelNumber;
	 }

	 public void setProductTypeCode(String ProductTypeCode) {
	  this.ProductTypeCode = ProductTypeCode;
	 }

	 public void setProductTypeDescription(String ProductTypeDescription) {
	  this.ProductTypeDescription = ProductTypeDescription;
	 }

	 public void setProductCategoryCode(String ProductCategoryCode) {
	  this.ProductCategoryCode = ProductCategoryCode;
	 }

	 public void setProductCategoryDescription(String ProductCategoryDescription) {
	  this.ProductCategoryDescription = ProductCategoryDescription;
	 }

	 public void setProductSubCategoryCode(String ProductSubCategoryCode) {
	  this.ProductSubCategoryCode = ProductSubCategoryCode;
	 }

	 public void setProductSubCategoryDescription(String ProductSubCategoryDescription) {
	  this.ProductSubCategoryDescription = ProductSubCategoryDescription;
	 }

	 public void setProductFamilyCode(String ProductFamilyCode) {
	  this.ProductFamilyCode = ProductFamilyCode;
	 }

	 public void setProductFamilyDescription(String ProductFamilyDescription) {
	  this.ProductFamilyDescription = ProductFamilyDescription;
	 }

	 public void setProductSeriesCode(String ProductSeriesCode) {
	  this.ProductSeriesCode = ProductSeriesCode;
	 }

	 public void setProductSeriesDescription(String ProductSeriesDescription) {
	  this.ProductSeriesDescription = ProductSeriesDescription;
	 }

	 public void setProductModelCode(String ProductModelCode) {
	  this.ProductModelCode = ProductModelCode;
	 }

	 public void setProductModelDescription(String ProductModelDescription) {
	  this.ProductModelDescription = ProductModelDescription;
	 }
	}*/

package com.hpe.mast.kafka.bean;

public class ProductHierarchy {
	
	public String SourceSystemCode;
	public String ProductHierarchyCode;
	public String ProductHierarchyDescription;
	public float ProductHierarchyLevelNumber;
	public String ProductTypeCode;
	public String ProductTypeDescription;
	public String ProductCategoryCode;
	public String ProductCategoryDescription;
	public String ProductSubCategoryCode;
	public String ProductSubCategoryDescription;
	public String ProductFamilyCode;
	public String ProductFamilyDescription;
	public String ProductSeriesCode;
	public String ProductSeriesDescription;
	public String ProductModelCode;
	public String ProductModelDescription;
	public String getSourceSystemCode() {
		return SourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		SourceSystemCode = sourceSystemCode;
	}
	public String getProductHierarchyCode() {
		return ProductHierarchyCode;
	}
	public void setProductHierarchyCode(String productHierarchyCode) {
		ProductHierarchyCode = productHierarchyCode;
	}
	public String getProductHierarchyDescription() {
		return ProductHierarchyDescription;
	}
	public void setProductHierarchyDescription(String productHierarchyDescription) {
		ProductHierarchyDescription = productHierarchyDescription;
	}
	public float getProductHierarchyLevelNumber() {
		return ProductHierarchyLevelNumber;
	}
	public void setProductHierarchyLevelNumber(float productHierarchyLevelNumber) {
		ProductHierarchyLevelNumber = productHierarchyLevelNumber;
	}
	public String getProductTypeCode() {
		return ProductTypeCode;
	}
	public void setProductTypeCode(String productTypeCode) {
		ProductTypeCode = productTypeCode;
	}
	public String getProductTypeDescription() {
		return ProductTypeDescription;
	}
	public void setProductTypeDescription(String productTypeDescription) {
		ProductTypeDescription = productTypeDescription;
	}
	public String getProductCategoryCode() {
		return ProductCategoryCode;
	}
	public void setProductCategoryCode(String productCategoryCode) {
		ProductCategoryCode = productCategoryCode;
	}
	public String getProductCategoryDescription() {
		return ProductCategoryDescription;
	}
	public void setProductCategoryDescription(String productCategoryDescription) {
		ProductCategoryDescription = productCategoryDescription;
	}
	public String getProductSubCategoryCode() {
		return ProductSubCategoryCode;
	}
	public void setProductSubCategoryCode(String productSubCategoryCode) {
		ProductSubCategoryCode = productSubCategoryCode;
	}
	public String getProductSubCategoryDescription() {
		return ProductSubCategoryDescription;
	}
	public void setProductSubCategoryDescription(String productSubCategoryDescription) {
		ProductSubCategoryDescription = productSubCategoryDescription;
	}
	public String getProductFamilyCode() {
		return ProductFamilyCode;
	}
	public void setProductFamilyCode(String productFamilyCode) {
		ProductFamilyCode = productFamilyCode;
	}
	public String getProductFamilyDescription() {
		return ProductFamilyDescription;
	}
	public void setProductFamilyDescription(String productFamilyDescription) {
		ProductFamilyDescription = productFamilyDescription;
	}
	public String getProductSeriesCode() {
		return ProductSeriesCode;
	}
	public void setProductSeriesCode(String productSeriesCode) {
		ProductSeriesCode = productSeriesCode;
	}
	public String getProductSeriesDescription() {
		return ProductSeriesDescription;
	}
	public void setProductSeriesDescription(String productSeriesDescription) {
		ProductSeriesDescription = productSeriesDescription;
	}
	public String getProductModelCode() {
		return ProductModelCode;
	}
	public void setProductModelCode(String productModelCode) {
		ProductModelCode = productModelCode;
	}
	public String getProductModelDescription() {
		return ProductModelDescription;
	}
	public void setProductModelDescription(String productModelDescription) {
		ProductModelDescription = productModelDescription;
	}
	
	

}
