package com.hpe.mast.kafka.consumer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.hpe.mast.kafka.bean.PartitionOffsetBean;
import com.hpe.mast.kafka.bean.PricingInformation;
import com.hpe.mast.kafka.bean.PricingMaster;

@Service
@PropertySource({ "classpath:application.properties" })
public class PricingListener implements ConsumerSeekAware {

	private static final Logger LOG = LoggerFactory.getLogger(PricingListener.class);

	@Autowired
	MastDBDao mastDBDao;

	@Value("${pricingHierarchy}")
	private String topicName;

	@KafkaListener(group = "S4-MAST_hpit-ifsl_group", topics = "PRICING_DETAILS_SERP_hpit-ifsl", containerFactory = "pricingListenerContainerFactory")
	public void receivePricing(@Payload List<PricingMaster> messages,
			@Header(KafkaHeaders.RECEIVED_PARTITION_ID) List<Integer> partitions,
			@Header(KafkaHeaders.OFFSET) List<Long> offsets, Acknowledgment acknowledgment) throws ParseException {
		LOG.info("---******---PRICING TOPIC STARTED---******---");
		for (int i = 0; i < messages.size(); i++) {
			PartitionOffsetBean partitionData = new PartitionOffsetBean();
			PricingMaster pricingMaster = messages.get(i);

			try {
				if (null != messages.get(i).getPricingDetails()) {
					List<PricingInformation> pricingInformation = messages.get(i).getPricingDetails();
					if (null != pricingInformation.get(0).getListPriceValidFromDate()
							&& null != pricingInformation.get(0).getListPriceValidtoDate()
							&& null != pricingInformation.get(0).getCurrencyCode()
							&& null != pricingInformation.get(0).getCountryCode()
							&& null != pricingInformation.get(0).getIncotermscode()
							&& null != pricingInformation.get(0).getAvailableMaterialIdentifier())

					{
						pricingMaster = messages.get(i);
						PricingInformation pricingInfo = pricingMaster.getPricingDetails().get(0);
						mastDBDao.savePricingData(pricingInfo);
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				LOG.info("---EXCEPTION WHILE FORMING PRICING OBJECT FROM JSON RESPONSE---");
			}
			// acknowledgment.acknowledge();
			partitionData.setTopic(topicName);
			partitionData.setPartition(partitions.get(i));
			partitionData.setOffset(offsets.get(i));
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			partitionData.setUpdatedTime(timeStamp);
			mastDBDao.saveOffsetData(partitionData);
		}
		LOG.info("---LIST PRICING CONSUMER END---");
	}

	@Override
	public void registerSeekCallback(ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onPartitionsAssigned(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		try {
			List<PartitionOffsetBean> partitionOffsetList = mastDBDao.fetchOffsetData(topicName);
			if (partitionOffsetList == null || partitionOffsetList.size() <= 0) {
				Set<TopicPartition> topicInitialData = assignments.keySet();
				Iterator<TopicPartition> it = topicInitialData.iterator();
				while (it.hasNext()) {
					TopicPartition topic = it.next();
					callback.seek(topic.topic(), topic.partition(), 0);
				}
			} 
			else {
				Map<Integer, TopicPartition> partitionFound = new HashMap<Integer, TopicPartition>();
				Set<TopicPartition> topicInitialData = assignments.keySet();
				for (int i = 0; i < partitionOffsetList.size(); i++) {
					Iterator<TopicPartition> it = topicInitialData.iterator();
					while (it.hasNext()) {
						TopicPartition topic = it.next();
						if (partitionOffsetList.get(i).getPartition() == topic.partition()) {
							callback.seek(topicName, partitionOffsetList.get(i).getPartition(),
									partitionOffsetList.get(i).getOffset());
							LOG.info("---PARTITION(S) ASSIGNED FOR 'LIST_PRICE' FROM DATABASE---" + partitionOffsetList.get(i).getPartition());
							partitionFound.put(topic.partition(), topic);
						}
						 
					}
				}
				Iterator<TopicPartition> it2 = topicInitialData.iterator();
				while (it2.hasNext()) {
					TopicPartition topic = it2.next();
					if(!partitionFound.containsKey(topic.partition())){
						callback.seek(topic.topic(), topic.partition(), 0);
						LOG.info("---PARTITION(S) ASSIGNED FOR 'LIST_PRICE' FROM S4---" +topic.partition());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("--+++--'LIST_PRICE' PARTITION ASSIGNMENT FAILED--+++--");
		}
	}

	@Override
	public void onIdleContainer(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

}
