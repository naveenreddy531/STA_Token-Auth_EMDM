package com.hpe.mast.kafka.consumer;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hpe.mast.kafka.bean.ExchangeRate;
import com.hpe.mast.kafka.bean.MaterialMaster;
import com.hpe.mast.kafka.bean.PartitionOffsetBean;
import com.hpe.mast.kafka.bean.PricingInformation;

@Service
public interface MastDBDao {
	
	public Integer saveOffsetData(PartitionOffsetBean partitionData);
	
	public void saveProdHierarchyBatch(MaterialMaster materialMaster);
	
	public List<PartitionOffsetBean> fetchOffsetData(String topicName);
	
	public void savePricingData(PricingInformation pricingInformation);
	
	public void saveExchangeRates(ExchangeRate exchangeRate);

}
