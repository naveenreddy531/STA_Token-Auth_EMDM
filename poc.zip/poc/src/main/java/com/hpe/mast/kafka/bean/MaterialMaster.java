package com.hpe.mast.kafka.bean;

import java.util.List;

public class MaterialMaster {
	public String MaterialIdentifier="";
	public String SourceSystemCode;
	public String ProductHierarchyCode;
	public String SourceSystemCreateTimestamp;
	public String SourceSystemUpdateTimestamp;
	public ProductHierarchy ProductHierarchy;
	public MaterialStatus CrossPlantMaterialStatus;
	
	public SalesDivision SalesDivision;
	public List<MaterialLanguage> MaterialLanguage;
	
	public String getMaterialIdentifier() {
		return MaterialIdentifier;
	}
	public void setMaterialIdentifier(String materialIdentifier) {
		MaterialIdentifier = materialIdentifier;
	}
	
	public SalesDivision getSalesDivision() {
		return SalesDivision;
	}
	public void setSalesDivision(SalesDivision salesDivision) {
		SalesDivision = salesDivision;
	}
	public String getSourceSystemCode() {
		return SourceSystemCode;
	}
	public void setSourceSystemCode(String sourceSystemCode) {
		SourceSystemCode = sourceSystemCode;
	}
	public String getProductHierarchyCode() {
		return ProductHierarchyCode;
	}
	public void setProductHierarchyCode(String productHierarchyCode) {
		ProductHierarchyCode = productHierarchyCode;
	}
	public String getSourceSystemCreateTimestamp() {
		return SourceSystemCreateTimestamp;
	}
	public void setSourceSystemCreateTimestamp(String sourceSystemCreateTimestamp) {
		SourceSystemCreateTimestamp = sourceSystemCreateTimestamp;
	}
	public String getSourceSystemUpdateTimestamp() {
		return SourceSystemUpdateTimestamp;
	}
	public void setSourceSystemUpdateTimestamp(String sourceSystemUpdateTimestamp) {
		SourceSystemUpdateTimestamp = sourceSystemUpdateTimestamp;
	}
	public ProductHierarchy getProductHierarchy() {
		return ProductHierarchy;
	}
	public void setProductHierarchy(ProductHierarchy productHierarchy) {
		ProductHierarchy = productHierarchy;
	}
	public List<MaterialLanguage> getMaterialLanguage() {
		return MaterialLanguage;
	}
	public void setMaterialLanguage(List<MaterialLanguage> materialLanguage) {
		MaterialLanguage = materialLanguage;
	}
	
	public MaterialStatus getCrossPlantMaterialStatus() {
		return CrossPlantMaterialStatus;
	}
	public void setCrossPlantMaterialStatus(MaterialStatus crossPlantMaterialStatus) {
		CrossPlantMaterialStatus = crossPlantMaterialStatus;
	}
	
}
