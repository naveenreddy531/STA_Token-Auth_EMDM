package com.hpe.mast.kafka.bean;

import java.math.BigDecimal;

public class ListInfo {

	public BigDecimal UnitListPriceAmount;
	public int PricingConditionItemQuantity;
	public String CurrencyCode;
	
	public BigDecimal getUnitListPriceAmount() {
		return UnitListPriceAmount;
	}
	public void setUnitListPriceAmount(BigDecimal unitListPriceAmount) {
		UnitListPriceAmount = unitListPriceAmount;
	}
	public int getPricingConditionItemQuantity() {
		return PricingConditionItemQuantity;
	}
	public void setPricingConditionItemQuantity(int pricingConditionItemQuantity) {
		PricingConditionItemQuantity = pricingConditionItemQuantity;
	}
	public String getCurrencyCode() {
		return CurrencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		CurrencyCode = currencyCode;
	}
	
	
}
