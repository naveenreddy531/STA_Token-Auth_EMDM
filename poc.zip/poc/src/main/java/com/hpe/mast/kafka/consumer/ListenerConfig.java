package com.hpe.mast.kafka.consumer;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.AbstractMessageListenerContainer;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import com.hpe.mast.kafka.bean.ExchangeRate01;
import com.hpe.mast.kafka.bean.MaterialMaster;
import com.hpe.mast.kafka.bean.PricingMaster;


@EnableKafka
@Configuration

@PropertySource({"classpath:config/mast/dao.properties" })
public class ListenerConfig {
	
	static final Logger logger = Logger.getLogger(ListenerConfig.class);
	
	@Value("${mast.db.driverName}")
	private String driverName;
	@Value("${mast.db.url}")
	private String mastDBUrl;
	@Value("${mast.db.username}")
	private String userName;
	@Value("${mast.db.password}")
	private String password;
	
	@Value("${truststore.path}")
	private String truestStorePath;
	
	@Value("${keystore.path}")
	private String keystorePath;
	
	
	@Bean
	public DataSource myMastDataSource() throws Exception {
		logger.info("------------INSIDE DATA SOURCE INITIALIZER--------------");
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName(driverName);
		dataSource.setUrl(mastDBUrl);
		dataSource.setUsername(userName);
		dataSource.setPassword(password);
		logger.info("Data source");
		logger.info(dataSource.toString());
		return dataSource;
	}
	ConsumerApplication app=new ConsumerApplication();
	String path=app.path;
	//String path="D:\\";
	@Bean
    public Map<String, Object> consumerConfigs() {
		
        Map<String, Object> props = new HashMap<String, Object>();
        ClassLoader classLoader = getClass().getClassLoader();
    	File trustStoreFile = new File(classLoader.getResource("mpaas_kfk_truststore.jks").getFile());
    	File keyStoreFile = new File(classLoader.getResource("mpaas_kfk_keystore.jks").getFile());
    	
    	String filePath= Thread.currentThread().getContextClassLoader().getResource("mpaas_kfk_truststore.jks").getFile();
        /*System.setProperty("javax.net.ssl.trustStore", filePath);
        System.setProperty("javax.net.ssl.trustStorePassword", "wipro@123");*/
        // PATH INSIDE JAR C:\Users\du20013955\Desktop\Kafka\MAST...jar\BOOT-INF\classes\
        String filePath1= Thread.currentThread().getContextClassLoader().getResource("mpaas_kfk_keystore.jks").getFile();
        /*System.setProperty("javax.net.ssl.keyStore", filePath1);
        System.setProperty("javax.net.ssl.keyStorePassword", "wipro@123");*/
        
        
    	//String truststorefilename = trustStoreFile.getPath();
		//System.setProperty("javax.net.ssl.trustStore", truststorefilename);
		System.setProperty("javax.net.ssl.trustStorePassword", "wipro@123");
    	
    	//String truststorefilename = System.getProperty("CONFIG_DIR");
		//truststorefilename += "/" + System.getProperty("ENV") + "/truststore.jks";
    	
      //  props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "hc4t00601.itcs.hpecorp.net:9443,hc4t00602.itcs.hpecorp.net:9443,hc4t00603.itcs.hpecorp.net:9443,hc4t00604.itcs.hpecorp.net:9443,hc4t00605.itcs.hpecorp.net:9443");
		props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "hc4t02271.itcs.hpecorp.net:9443,hc4t02272.itcs.hpecorp.net:9443,hc4t02273.itcs.hpecorp.net:9443,hc4t02274.itcs.hpecorp.net:9443,hc4t02275.itcs.hpecorp.net:9443,hc4t02276.itcs.hpecorp.net:9443");
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
        props.put(ConsumerConfig.GROUP_ID_CONFIG, "S4-MAST_hpit-ifsl_group");//"NGQ_hpit-ifsl_group");
        //props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "1");
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL");
        props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,trustStoreFile.getAbsolutePath());
       
       //  path+"mpaas_kfk_truststore.jks");
      //  "C:\\Users\\du20013955\\Desktop\\Kafka\\mpaas_kfk_truststore.jks");
      
        //  "\\opt\\cloudhost\\mpaas_kfk_truststore.jks");
        props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, "wipro@123");
        props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, "wipro@123");
        props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,keyStoreFile.getAbsolutePath());///opt/cloudhost/tomcat7/security
      
      //   "C:\\Users\\du20013955\\Desktop\\Kafka\\mpaas_kfk_keystore.jks");
      //  path+"mpaas_kfk_keystore.jks");
       
        //  path+"mpaas_kfk_keystore.jks");
      //  props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, "wipro@123");
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false); 
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest");
        return props;
    }
	
	/* Bean Configuration for Product Hierarchy" */	 
    @Bean
    public DefaultKafkaConsumerFactory<String, MaterialMaster> consumerFactory() {
        return new DefaultKafkaConsumerFactory<String, MaterialMaster>(consumerConfigs(), new StringDeserializer(), new JsonDeserializer<>(MaterialMaster.class)); 
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, MaterialMaster> kafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, MaterialMaster> factory = new ConcurrentKafkaListenerContainerFactory<String, MaterialMaster>();
        factory.setConsumerFactory(consumerFactory());
        factory.setBatchListener(true);
        //factory.getContainerProperties().setGenericErrorHandler(new BatchLoggingErrorHandler());
       // factory.getContainerProperties().setAckOnError(false);
        factory.getContainerProperties().setAckMode(AbstractMessageListenerContainer.AckMode.MANUAL);
        factory.getContainerProperties().setSyncCommits(true);
        return factory;
    }
    
    
	/*  Bean Configuration for Pricing" */	 
    @Bean
    public DefaultKafkaConsumerFactory<String, PricingMaster> pricingconsumerFactory() {
        return new DefaultKafkaConsumerFactory<String, PricingMaster>(consumerConfigs(), new StringDeserializer(), new JsonDeserializer<>(PricingMaster.class)); 
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, PricingMaster> pricingListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, PricingMaster> factory = new ConcurrentKafkaListenerContainerFactory<String, PricingMaster>();
        factory.setConsumerFactory(pricingconsumerFactory());
        factory.setBatchListener(true);
        factory.getContainerProperties().setAckMode(AbstractMessageListenerContainer.AckMode.MANUAL);
        factory.getContainerProperties().setSyncCommits(true);
        return factory;
    }
    
    
	/* Bean Configuration for Exchange Rates*/
	 
    @Bean
    public DefaultKafkaConsumerFactory<String, ExchangeRate01> exchangeRatesconsumerFactory() {
        return new DefaultKafkaConsumerFactory<String, ExchangeRate01>(consumerConfigs(), new StringDeserializer(), new JsonDeserializer<>(ExchangeRate01.class)); 
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, ExchangeRate01> exchangeRatesContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, ExchangeRate01> factory = new ConcurrentKafkaListenerContainerFactory<String, ExchangeRate01>();
        factory.setConsumerFactory(exchangeRatesconsumerFactory());
        factory.setBatchListener(true);
        factory.getContainerProperties().setAckMode(AbstractMessageListenerContainer.AckMode.MANUAL);
        factory.getContainerProperties().setSyncCommits(true);
        return factory;
    }


}
