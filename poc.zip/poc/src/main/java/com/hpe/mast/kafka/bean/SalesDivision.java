package com.hpe.mast.kafka.bean;

	
	public class SalesDivision {
		 public String SourceSystemCode;
		 public String SalesDivisionCode;
		 public String SalesDivisionDescription;


		 // Getter Methods 

		 public String getSourceSystemCode() {
		  return SourceSystemCode;
		 }

		 public String getSalesDivisionCode() {
		  return SalesDivisionCode;
		 }

		 public String getSalesDivisionDescription() {
		  return SalesDivisionDescription;
		 }

		 // Setter Methods 

		 public void setSourceSystemCode(String SourceSystemCode) {
		  this.SourceSystemCode = SourceSystemCode;
		 }

		 public void setSalesDivisionCode(String SalesDivisionCode) {
		  this.SalesDivisionCode = SalesDivisionCode;
		 }

		 public void setSalesDivisionDescription(String SalesDivisionDescription) {
		  this.SalesDivisionDescription = SalesDivisionDescription;
		 }
		}
	


