package com.hpe.mast.kafka.consumer;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;


@SpringBootApplication
public class ConsumerApplication extends SpringBootServletInitializer{
	public static String path;
	
	@Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(ConsumerApplication.class);
    }
	
	public static void main(String[] args) {
	//	path= args[0];
		PropertyConfigurator.configure("log4j.properties");
		String filepath = "src/main/resources/";
		System.setProperty("CONFIG_DIR",filepath );
		SpringApplication.run(ConsumerApplication.class, args);
	}

	
}


/*package com.hpe.mast.kafka.consumer;

import org.apache.log4j.PropertyConfigurator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.support.SpringBootServletInitializer;


@SpringBootApplication
public class ConsumerApplication {
	public static String path;
	
	public static void main(String[] args) {
		//path= args[0];
		PropertyConfigurator.configure("log4j.properties");
		SpringApplication.run(ConsumerApplication.class, args);
	}

	
}*/
