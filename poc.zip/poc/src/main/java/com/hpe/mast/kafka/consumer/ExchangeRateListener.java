package com.hpe.mast.kafka.consumer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.common.TopicPartition;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.hpe.mast.kafka.bean.ExchangeRate;
import com.hpe.mast.kafka.bean.ExchangeRate01;
import com.hpe.mast.kafka.bean.ExchangeRate01.EXCHANGE_RATE01.IDOC;
import com.hpe.mast.kafka.bean.PartitionOffsetBean;

@Service
@PropertySource({ "classpath:application.properties" })
public class ExchangeRateListener implements ConsumerSeekAware {

	private static final Logger LOG = LoggerFactory.getLogger(ExchangeRateListener.class);

	@Autowired
	MastDBDao mastDBDao;

	@Value("${exchangeRates}")
	private String topicName;

	@KafkaListener(group = "S4-MAST_hpit-ifsl_group", topics = "EXCHANGE_RATE_SERP_hpit-ifsl", containerFactory = "exchangeRatesContainerFactory")
	public void receive3(@Payload List<ExchangeRate01> messages,
			@Header(KafkaHeaders.RECEIVED_PARTITION_ID) List<Integer> partitions,
			@Header(KafkaHeaders.OFFSET) List<Long> offsets, @Header(KafkaHeaders.RECEIVED_TOPIC) List<String> topics,
			Acknowledgment acknowledgment) throws ParseException {
		// List<MaterialMaster> productMaterialList = new ArrayList<>();
		LOG.info("---******---EXCHANGE RATES TOPIC STARTED---******---");
		for (int i = 0; i < messages.size(); i++) {
			PartitionOffsetBean partitionData = new PartitionOffsetBean();
			ExchangeRate01 exchangeRate01 = messages.get(i);
			Gson gson = new Gson();
			try {
				if (null != messages.get(i).getEXCHANGE_RATE01()) {
					IDOC idoc = messages.get(i).getEXCHANGE_RATE01().getIDOC();
					if (null != idoc.getE1EXCHANGE_RATE()) {
						if ((idoc.getE1EXCHANGE_RATE().getE1BP1093_0()) instanceof List) {
							String jsonarray = idoc.getE1EXCHANGE_RATE().getE1BP1093_0().toString();
							JSONArray array = new JSONArray(jsonarray);
							ArrayList<ExchangeRate> exchangeRateList = gson.fromJson(array.toString(), ArrayList.class);
							
							if (exchangeRateList.size() > 0) {
								for (int j = 0; j < exchangeRateList.size(); j++) {
									JSONObject item = array.getJSONObject(j);
									String json = gson.toJson(exchangeRateList.get(j));
									ExchangeRate rate = gson.fromJson(json, ExchangeRate.class);
									if (null != rate.getEXCH_RATE()
											&& null != rate.getFROM_CURR()
											&& null != rate.getRATE_TYPE()
											&& null != rate.getTO_CURRNCY()
											&& null != rate.getVALID_FROM()) {
										if (rate.getRATE_TYPE().equalsIgnoreCase("M")|| rate.getRATE_TYPE().equalsIgnoreCase("P")) {
											rate.setVALID_FROM(item.getString("VALID_FROM"));
											mastDBDao.saveExchangeRates(rate);
										}
									}
								}
							}
						} else {
							if(idoc.getE1EXCHANGE_RATE().getE1BP1093_0() != null){
							ExchangeRate rate = gson.fromJson(idoc.getE1EXCHANGE_RATE().getE1BP1093_0().toString(), ExchangeRate.class);
							mastDBDao.saveExchangeRates(rate);
							}

						}
					}
				}

				partitionData.setTopic(topicName);
				partitionData.setPartition(partitions.get(i));
				partitionData.setOffset(offsets.get(i));
				String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
				partitionData.setUpdatedTime(timeStamp);
				mastDBDao.saveOffsetData(partitionData);
			} catch (Exception e) {
				e.printStackTrace();
				LOG.info("---EXCEPTION WHILE FORMING EXCHANGE-RATE OBJECT FROM JSON RESPONSE---");
			}
			
		}
		LOG.info("---EXCHANGE-RATE CONSUMER END---");
	}
	
	@Override
	public void registerSeekCallback(ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onPartitionsAssigned(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		try {
			List<PartitionOffsetBean> partitionOffsetList = mastDBDao.fetchOffsetData(topicName);
			if (partitionOffsetList == null || partitionOffsetList.size() <= 0) {
				Set<TopicPartition> topicInitialData = assignments.keySet();
				Iterator<TopicPartition> it = topicInitialData.iterator();
				while (it.hasNext()) {
					TopicPartition topic = it.next();
					callback.seek(topic.topic(), topic.partition(), 0);
				}
			} 
			else {
				Map<Integer, TopicPartition> partitionFound = new HashMap<Integer, TopicPartition>();
				Set<TopicPartition> topicInitialData = assignments.keySet();
				for (int i = 0; i < partitionOffsetList.size(); i++) {
					Iterator<TopicPartition> it = topicInitialData.iterator();
					while (it.hasNext()) {
						TopicPartition topic = it.next();
						if (partitionOffsetList.get(i).getPartition() == topic.partition()) {
							callback.seek(topicName, partitionOffsetList.get(i).getPartition(),
									partitionOffsetList.get(i).getOffset());
							LOG.info("---PARTITION(S) ASSIGNED FOR 'EXCH_RATES' FROM DATABASE---" + partitionOffsetList.get(i).getPartition());
							partitionFound.put(topic.partition(), topic);
						}
						 
					}
				}
				Iterator<TopicPartition> it2 = topicInitialData.iterator();
				while (it2.hasNext()) {
					TopicPartition topic = it2.next();
					if(!partitionFound.containsKey(topic.partition())){
						callback.seek(topic.topic(), topic.partition(), 0);
						LOG.info("---PARTITION(S) ASSIGNED FOR 'EXCH_RATES' FROM S4---" +topic.partition());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("--+++--'EXCH_RATES' PARTITION ASSIGNMENT FAILED--+++--");
		}
	}

	@Override
	public void onIdleContainer(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub

	}

}
