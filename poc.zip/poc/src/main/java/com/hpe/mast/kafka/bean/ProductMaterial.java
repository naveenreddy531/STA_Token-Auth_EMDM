package com.hpe.mast.kafka.bean;

import java.util.List;

public class ProductMaterial {

	private String prodNbr;
	private String prodModelCode;
	private String prodModelDesc;
	private String prodOptionCode;
	private String prodSeriesCode;
	private String prodSeriesDesc;
	private String prodFamilyCode;
	private String prodFamilyDesc;
	private String buCode;
	private String buDesc;
	private String bgCode;
	private String bgDesc;
	private String defaultForProd;
	private String prodLineCode;
	private String prodLineDesc;
	private String prodSubCatgyCode;
	private String prodSubCatgyDesc;
	private String prodCatgyCode;
	private String prodCatgyDesc;
	private String prodGroupCode;
	private String prodGroupDesc;
	private String extractTimeStamp;

	/*
	 * OFFSET PRODUCT_NR PRODUCT_MODEL_CODE PRODUCT_MODEL_DESC
	 * PRODUCT_OPTION_CODE PRODUCT_SERIES_CODE PRODUCT_SERIES_DESC
	 * PRODUCT_FAMILY_DESC PRODUCT_FAMILY_CODE BU_CODE BU_DESC BG_CODE BG_DESC
	 * DEFAULT_FOR_PROD PRODUCT_LINE_CODE PRODUCT_LINE_DESC PRODUCT_CAT_CODE
	 * PRODUCT_CAT_DESC PRODUCT_GROUP_CODE PRODUCT_GROUP_DESC EXTRACT_TIME_STAMP
	 * INSERTED_TIMESTAMP
	 */

	public String getProdNbr() {
		return prodNbr;
	}

	public String getProdSubCatgyCode() {
		return prodSubCatgyCode;
	}

	public void setProdSubCatgyCode(String prodSubCatgyCode) {
		this.prodSubCatgyCode = prodSubCatgyCode;
	}

	public String getProdSubCatgyDesc() {
		return prodSubCatgyDesc;
	}

	public void setProdSubCatgyDesc(String prodSubCatgyDesc) {
		this.prodSubCatgyDesc = prodSubCatgyDesc;
	}

	public void setProdNbr(String prodNbr) {
		this.prodNbr = prodNbr;
	}

	public String getProdModelCode() {
		return prodModelCode;
	}

	public void setProdModelCode(String prodModelCode) {
		this.prodModelCode = prodModelCode;
	}

	public String getProdModelDesc() {
		return prodModelDesc;
	}

	public void setProdModelDesc(String prodModelDesc) {
		this.prodModelDesc = prodModelDesc;
	}

	public String getProdOptionCode() {
		return prodOptionCode;
	}

	public void setProdOptionCode(String prodOptionCode) {
		this.prodOptionCode = prodOptionCode;
	}

	public String getProdSeriesCode() {
		return prodSeriesCode;
	}

	public void setProdSeriesCode(String prodSeriesCode) {
		this.prodSeriesCode = prodSeriesCode;
	}

	public String getProdSeriesDesc() {
		return prodSeriesDesc;
	}

	public void setProdSeriesDesc(String prodSeriesDesc) {
		this.prodSeriesDesc = prodSeriesDesc;
	}

	public String getProdFamilyCode() {
		return prodFamilyCode;
	}

	public void setProdFamilyCode(String prodFamilyCode) {
		this.prodFamilyCode = prodFamilyCode;
	}

	public String getProdFamilyDesc() {
		return prodFamilyDesc;
	}

	public void setProdFamilyDesc(String prodFamilyDesc) {
		this.prodFamilyDesc = prodFamilyDesc;
	}

	public String getBuCode() {
		return buCode;
	}

	public void setBuCode(String buCode) {
		this.buCode = buCode;
	}

	public String getBuDesc() {
		return buDesc;
	}

	public void setBuDesc(String buDesc) {
		this.buDesc = buDesc;
	}

	public String getBgCode() {
		return bgCode;
	}

	public void setBgCode(String bgCode) {
		this.bgCode = bgCode;
	}

	public String getBgDesc() {
		return bgDesc;
	}

	public void setBgDesc(String bgDesc) {
		this.bgDesc = bgDesc;
	}

	public String getDefaultForProd() {
		return defaultForProd;
	}

	public void setDefaultForProd(String defaultForProd) {
		this.defaultForProd = defaultForProd;
	}

	public String getProdLineCode() {
		return prodLineCode;
	}

	public void setProdLineCode(String prodLineCode) {
		this.prodLineCode = prodLineCode;
	}

	public String getProdLineDesc() {
		return prodLineDesc;
	}

	public void setProdLineDesc(String prodLineDesc) {
		this.prodLineDesc = prodLineDesc;
	}

	public String getProdCatgyCode() {
		return prodCatgyCode;
	}

	public void setProdCatgyCode(String prodCatgyCode) {
		this.prodCatgyCode = prodCatgyCode;
	}

	public String getProdCatgyDesc() {
		return prodCatgyDesc;
	}

	public void setProdCatgyDesc(String prodCatgyDesc) {
		this.prodCatgyDesc = prodCatgyDesc;
	}

	public String getProdGroupCode() {
		return prodGroupCode;
	}

	public void setProdGroupCode(String prodGroupCode) {
		this.prodGroupCode = prodGroupCode;
	}

	public String getProdGroupDesc() {
		return prodGroupDesc;
	}

	public void setProdGroupDesc(String prodGroupDesc) {
		this.prodGroupDesc = prodGroupDesc;
	}

	public String getExtractTimeStamp() {
		return extractTimeStamp;
	}

	public void setExtractTimeStamp(String extractTimeStamp) {
		this.extractTimeStamp = extractTimeStamp;
	}

	@Override 
	public String toString(){
		return getProdNbr()+"  "+getProdCatgyCode()+"  "+getProdCatgyDesc()+"  "+getProdFamilyCode()+"  "+getProdFamilyDesc();
	}
}
