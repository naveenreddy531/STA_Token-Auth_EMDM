package com.hpe.mast.kafka.consumer;


import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.sql.DataSource;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import com.hpe.mast.kafka.bean.ExchangeRate;
import com.hpe.mast.kafka.bean.ListInfo;
import com.hpe.mast.kafka.bean.MaterialLanguage;
import com.hpe.mast.kafka.bean.MaterialMaster;
import com.hpe.mast.kafka.bean.MaterialStatus;
import com.hpe.mast.kafka.bean.PartitionOffsetBean;
import com.hpe.mast.kafka.bean.PricingInformation;
import com.hpe.mast.kafka.bean.ProductHierarchy;
import com.hpe.mast.kafka.bean.SalesDivision;

@Service
public class MastDBDaoImpl implements MastDBDao {

	private static final Logger LOG = LoggerFactory.getLogger(MastDBDaoImpl.class);

	private JdbcTemplate jdbcTemplate;

	public MastDBDaoImpl(DataSource dataSource) throws SQLException {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<PartitionOffsetBean> fetchOffsetData(String topicName) {
		String sql = "select * from S4_PARTITION_OFFSET where TOPIC= '" + topicName + "'";
		List<PartitionOffsetBean> partitionDataList = null;
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		try {
			RowMapper<PartitionOffsetBean> partitionDataGridEntityMapper = new RowMapper<PartitionOffsetBean>() {
				public PartitionOffsetBean mapRow(ResultSet rs, int rowNum) throws SQLException {
					PartitionOffsetBean partitionDataEntity = new PartitionOffsetBean();
					partitionDataEntity.setTopic(rs.getString("TOPIC"));
					partitionDataEntity.setPartition(rs.getInt("PARTITION"));
					partitionDataEntity.setOffset(rs.getInt("OFFSET"));
					return partitionDataEntity;
				}
			};
			partitionDataList = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).query(sql, parameters,
					partitionDataGridEntityMapper);
		} catch (Exception e) {
			LOG.info("ERROR WHILE FETCHING OFFSETS DATA");
		}
		return partitionDataList;
	}

	public Integer saveOffsetData(PartitionOffsetBean partitionData) {
		int res = -1;
		String sql = null;
		try {
			MapSqlParameterSource parameters = new MapSqlParameterSource();
			JSONArray templateData = null;
			if (partitionData != null) {
				parameters.addValue("topic", partitionData.getTopic());
				parameters.addValue("partition", partitionData.getPartition());
				parameters.addValue("offset", partitionData.getOffset());
				parameters.addValue("updatedTime", partitionData.getUpdatedTime());
			}

			sql = "Update S4_PARTITION_OFFSET set OFFSET =:offset,PARTITION=:partition,UPDATED_TIME=:updatedTime where TOPIC=:topic and PARTITION=:partition";
			res = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql, parameters);

			if (res == 0) {
				sql = " Insert into S4_PARTITION_OFFSET (TOPIC,PARTITION,OFFSET,UPDATED_TIME) VALUES (:topic,:partition,:offset,:updatedTime)";
				res = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql, parameters);
			}

		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("MAST DB OFFSET INSERTION FAILURE");
		}
		return res;
	}

	public void saveProdHierarchyBatch(MaterialMaster materialMaster) {
		String optionCode = "";
		String sql = "";
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());

		String sqlcheck = "SELECT count(*) FROM S4_PRODUCT_HIERARCHY_MASTER where PRODUCT_NR = ?";
		int count = jdbcTemplate.queryForObject(sqlcheck, new Object[] { materialMaster.getMaterialIdentifier() },
				Integer.class);

		ProductHierarchy productHierarchy = materialMaster.getProductHierarchy();
		SalesDivision salesDivision = materialMaster.getSalesDivision();
		MaterialLanguage materialLanguage = materialMaster.getMaterialLanguage().get(0);
		MaterialStatus materialStatus = materialMaster.getCrossPlantMaterialStatus();
		String prodNr = materialMaster.getMaterialIdentifier();
		if (prodNr.indexOf("#") != -1) {
			optionCode = prodNr.split("#")[1];
		}
		try {
			
			//Long parsedDate = Long.parseLong(materialMaster.getSourceSystemCreateTimestamp());
			String newCreateTimestamp = deleteCharAt(materialMaster.getSourceSystemCreateTimestamp(),8); 
			String newUpdatedTimeStamp = deleteCharAt(materialMaster.getSourceSystemCreateTimestamp(),8);
			/*
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
			Timestamp dateStamp = new Timestamp(parsedDate);
			Date inDate = new Date(dateStamp.getTime());
			sdf.format(inDate); */
			java.util.Date date = new java.util.Date();
			long t = date.getTime();
			java.sql.Date sqlDate = new java.sql.Date(t);
			
			 Date createdTimeStamp = convertDate(newCreateTimestamp);
			 Date updatedTimeStamp = convertDate(newUpdatedTimeStamp);
			
			SqlParameterSource paramSource = new MapSqlParameterSource()
					.addValue("prodNr", materialMaster.getMaterialIdentifier()).addValue("optCode", optionCode)
					.addValue("srcSystemCode", materialMaster.getSourceSystemCode())
					// .addValue("prodHierCode",
					// productMaterial.getProductHierarchyCode())
					.addValue("srcSysCreatedTime", createdTimeStamp)
					.addValue("srcSysUpdateTime", updatedTimeStamp)

					.addValue("prodHierCode", productHierarchy.getProductHierarchyCode())
					.addValue("prodHierDesc", productHierarchy.getProductHierarchyDescription())
					.addValue("prodHierLevelNr", productHierarchy.getProductHierarchyLevelNumber())
					.addValue("prodTypeCode", productHierarchy.getProductTypeCode())
					.addValue("prodTypeDesc", productHierarchy.getProductTypeDescription())
					.addValue("prodCatCode", productHierarchy.getProductCategoryCode())
					.addValue("prodCatDesc", productHierarchy.getProductCategoryDescription())
					.addValue("prodSubCatCode", productHierarchy.getProductSubCategoryCode())
					.addValue("prodSubCatDesc", productHierarchy.getProductSubCategoryDescription())
					.addValue("prodFamilyCode", productHierarchy.getProductFamilyCode())
					.addValue("prodFamilyDesc", productHierarchy.getProductFamilyDescription())
					.addValue("prodSeriesCode", productHierarchy.getProductSeriesCode())
					.addValue("prodSeriesDesc", productHierarchy.getProductSeriesDescription())
					.addValue("prodModelCode", productHierarchy.getProductModelCode())
					.addValue("prodModelDesc", productHierarchy.getProductModelDescription())

					.addValue("salesDivCode", salesDivision.getSalesDivisionCode())
					.addValue("salesDivDesc", salesDivision.getSalesDivisionDescription())

					// .addValue("materialIdentifier",
					// materialLanguage.getMaterialIdentifier())
					.addValue("isoLangCode", materialLanguage.getISOLanguageCode())
					.addValue("materialDesc", materialLanguage.getMaterialDescription()).addValue("defaultForProd", "n")
					.addValue("insertedTimestamp", timeStamp)
					.addValue("materialStatus", materialStatus.getCrossPlantMaterialStatusCode())
					.addValue("materialStatusDesc", materialStatus.getCrossPlantMaterialStatusDescription())
					.addValue("createdDate", sqlDate);

			if (count <= 0) {
				
				sql = "Insert into S4_PRODUCT_HIERARCHY_MASTER (PRODUCT_NR,PRODUCT_OPTION_CODE,SRC_CD,"
						+ "SRC_SYS_CRTD_TIME,SRC_UPDT_TIME,PROD_HIER_CD,"
						+ "PROD_HIER_DESC,PROD_HIER_LVL_NBR,BG_CODE,BG_DESC,"
						+ "PRODUCT_CAT_CODE,PRODUCT_CAT_DESC,PRODUCT_SUBCAT_CODE,"
						+ "PRODUCT_SUBCAT_DESC,PRODUCT_FAMILY_CODE,"
						+ "PRODUCT_FAMILY_DESC,PRODUCT_SERIES_CODE,PRODUCT_SERIES_DESC,"
						+ "PRODUCT_MODEL_CODE,PRODUCT_MODEL_DESC,"
						+ "PRODUCT_LINE_CODE,PRODUCT_LINE_DESC,ISO_LANG_CD,PROD_DESC,DEFAULT_FOR_PROD,INSERTED_TIMESTAMP,BU_CODE,BU_DESC,PROD_STATUS_CODE,PROD_STATUS_DESC,CREATED_DATE"
						+ ") VALUES (:prodNr,:optCode,:srcSystemCode,"
						+ ":srcSysCreatedTime,:srcSysUpdateTime,:prodHierCode,"
						+ ":prodHierDesc,:prodHierLevelNr,:prodTypeCode,:prodTypeDesc"
						+ ",:prodCatCode,:prodCatDesc,:prodSubCatCode,:prodSubCatDesc,:prodFamilyCode,"
						+ ":prodFamilyDesc,:prodSeriesCode,"
						+ ":prodSeriesDesc,:prodModelCode,:prodModelDesc,:salesDivCode,"
						+ ":salesDivDesc,:isoLangCode,:materialDesc,:defaultForProd,:insertedTimestamp,:prodCatCode,:prodCatDesc,:materialStatus,:materialStatusDesc,:createdDate)";
				// GROUP CODE, GROUP DESC,
				int successFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql,
						paramSource);
			} else {
				sql = "UPDATE S4_PRODUCT_HIERARCHY_MASTER SET "
						+ "PRODUCT_OPTION_CODE=:prodNr,SRC_CD=:srcSystemCode,SRC_SYS_CRTD_TIME=:srcSysCreatedTime,"
						+ "SRC_UPDT_TIME=:srcSysUpdateTime,PROD_HIER_CD=:prodHierCode,PROD_HIER_DESC=:prodHierDesc,"
						+ "PROD_HIER_LVL_NBR=:prodHierLevelNr,BG_CODE=:prodTypeCode,BG_DESC=:prodTypeDesc,PRODUCT_CAT_CODE=:prodCatCode,"
						+ "PRODUCT_CAT_DESC=:prodCatDesc,PRODUCT_SUBCAT_CODE=:prodSubCatCode,PRODUCT_SUBCAT_DESC=:prodSubCatDesc,"
						+ "PRODUCT_FAMILY_CODE=:prodFamilyCode,PRODUCT_FAMILY_DESC=:prodFamilyDesc,PRODUCT_SERIES_CODE=:prodSeriesCode,"
						+ "PRODUCT_SERIES_DESC=:prodSeriesDesc,PRODUCT_MODEL_CODE=:prodModelCode,PRODUCT_MODEL_DESC=:prodModelDesc,"
						+ "PRODUCT_LINE_CODE=:salesDivCode,PRODUCT_LINE_DESC=:salesDivDesc,ISO_LANG_CD=:isoLangCode,"
						+ "PROD_DESC=:materialDesc,DEFAULT_FOR_PROD=:defaultForProd,INSERTED_TIMESTAMP=:insertedTimestamp,BU_CODE=:prodCatCode,BU_DESC=:prodCatDesc,PROD_STATUS_CODE=:materialStatus,PROD_STATUS_DESC=:materialStatusDesc,CREATED_DATE=:createdDate WHERE PRODUCT_NR=:prodNr";

				int successFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql,
						paramSource);
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("MAST DB PRODUCT HIERARCHY INSERTION FAILURE");
		}

	}
	
	/*
	 * Methods Used for converting string to sql Date
	 */
	
	private static String deleteCharAt(String strValue, int index) {
		return strValue.substring(0, index);

	} 
	public String getDateInDateMonthYear(String dateConvert) {
		Long parsedDate = Long.parseLong(dateConvert);
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MMM/yyyy");
		Timestamp dateStamp = new Timestamp(parsedDate);
		Date inDate = new Date(dateStamp.getTime());
		return sdf.format(inDate);
	}
	
	public Date convertDate(String date){
		StringBuffer fromdate = new StringBuffer(date);	
		fromdate.insert(4, "-");
		fromdate.insert(7, "-");
		Date frmDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			frmDate = new java.sql.Date(formatter.parse(fromdate.toString()).getTime());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return frmDate;
	}

	/*
	 * Method to save Pricing Hierarchy Data
	 */
	
	public void savePricingData(PricingInformation pricingInformation) {
		List<ListInfo> pricingConditionItem = pricingInformation.getPricingConditionItem();
		ListInfo listInfo = pricingConditionItem.get(0);
		/*StringBuffer fromdate = new StringBuffer(pricingInformation.getListPriceValidFromDate());
		fromdate.insert(4, "-");
		fromdate.insert(7, "-");*/
		java.util.Date date = new java.util.Date();
		long t = date.getTime();
		java.sql.Date sqlDate = new java.sql.Date(t);
		StringBuffer toDate = new StringBuffer(pricingInformation.getListPriceValidtoDate().toString());
		toDate.insert(4, "-");
		toDate.insert(7, "-");
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date frmdate = null;
		Date to_date = null;

		try {
			to_date = new java.sql.Date(formatter.parse(toDate.toString()).getTime());
		} catch (Exception e) {
			LOG.info("----+++----CONVERSION OF 'TO_DATE' FOR '9999' CONDITION IN PRICING DATA FAILED----+++----");
		}
		if (toDate.substring(0, 4).equals("9999")) {
			to_date = null;
		}
		String ctryCode;
		if(pricingInformation.getCountryCode() == null){
			ctryCode = "-NA";
		}
		else{
			ctryCode = pricingInformation.getCountryCode();
		}
		String incoTerm;
		if(pricingInformation.getIncotermscode() == null){
			incoTerm = "-NA";
		}
		else{
			incoTerm = pricingInformation.getIncotermscode();
		}
		try {
			SqlParameterSource paramSource = new MapSqlParameterSource()

					.addValue("listPriceValidFromDate", convertDate(pricingInformation.getListPriceValidFromDate()))
					.addValue("listPriceValidToDate", to_date) // for checking "9999" condition, not used convertDate() 
					.addValue("currCode", pricingInformation.getCurrencyCode())
					.addValue("countryCode", ctryCode)
					.addValue("incoTermsCode", incoTerm)
					.addValue("mccMaterial", pricingInformation.getMCCMaterial())

					.addValue("avlMatIdentifier", pricingInformation.getAvailableMaterialIdentifier())
					.addValue("optionId", pricingInformation.getOptionID())
					.addValue("priceListTypeCode", pricingInformation.getPriceListTypeCode())
					.addValue("priceGeo", pricingInformation.getPriceGeo())

					.addValue("condCurrCode", listInfo.getCurrencyCode())
					.addValue("priceCondItmQty", listInfo.getPricingConditionItemQuantity())
					.addValue("unitListPriceAmt", listInfo.getUnitListPriceAmount())
					.addValue("createdDate", sqlDate);
			
			String sql = "Insert into TEMP_LISTPRICE  (FROM_DATE,TO_DATE,CURR_CD,CTRY_CD,INCOTERM,MCC_UP,PROD_NBR,OPT_CD,PRCLST_TYPE_CD,PRICE_GEO,COND_CURR_CD,PRC_COND_ITEM_QTY,UNITLISTPRICE,CREATED_DATE"
					+ " ) VALUES (:listPriceValidFromDate,:listPriceValidToDate,:currCode,"
					+ ":countryCode,:incoTermsCode,:mccMaterial,"
					+ ":avlMatIdentifier,:optionId,:priceListTypeCode,:priceGeo"
					+ ",:condCurrCode,:priceCondItmQty,:unitListPriceAmt,:createdDate)";
			int successFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql,
					paramSource);
			//truncateTable("TEMP_LISTPRICE");
			String updateQuery = "UPDATE S4_LISTPRICE S4LP SET  S4LP.TO_DATE = ( SELECT GLBLLP.FROM_DATE -1"
					+ " FROM TEMP_LISTPRICE GLBLLP WHERE (S4LP.PROD_NBR || S4LP.OPT_CD || S4LP.MCC_UP || "
					+ "S4LP.CTRY_CD || S4LP.CURR_CD || S4LP.INCOTERM) = (GLBLLP.PROD_NBR || GLBLLP.OPT_CD || "
					+ "GLBLLP.MCC_UP || GLBLLP.CTRY_CD || GLBLLP.CURR_CD || GLBLLP.INCOTERM) and S4LP.TO_DATE is NULL) "
					+ "WHERE EXISTS (SELECT GLBLLP.FROM_DATE -1 FROM TEMP_LISTPRICE GLBLLP,S4_LISTPRICE S4LPs WHERE (S4LP.PROD_NBR || "
					+ "S4LP.OPT_CD || S4LP.MCC_UP || S4LP.CTRY_CD || S4LP.CURR_CD || S4LP.INCOTERM) = (GLBLLP.PROD_NBR "
					+ "|| GLBLLP.OPT_CD || GLBLLP.MCC_UP || GLBLLP.CTRY_CD || GLBLLP.CURR_CD || GLBLLP.INCOTERM)and S4LP.TO_DATE is NULL)";

			int updateFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(updateQuery,
					new MapSqlParameterSource());

			if (updateFlag >= 1) {
				truncateTable("TEMP_LISTPRICE");
			} else {

				String insertQuery = "INSERT INTO S4_LISTPRICE Select PROD_NBR, OPT_CD, MCC_UP, CTRY_CD, CURR_CD, "
						+ "INCOTERM, UNITLISTPRICE, FROM_DATE, TO_DATE, PRCLST_TYPE_CD, PRICE_GEO, COND_CURR_CD, "
						+ "PRC_COND_ITEM_QTY ,CREATED_DATE from TEMP_LISTPRICE";
				int insertListPrice = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource())
						.update(insertQuery, new MapSqlParameterSource());
				truncateTable("TEMP_LISTPRICE");
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("MAST DB PRODUCT HIERARCHY INSERTION FAILURE");
		}
	}

	/*
	 * Method to save Exchange Rates Data
	 */
	public void saveExchangeRates(ExchangeRate exchangeRate) {
		
		java.util.Date date = new java.util.Date();
		long t = date.getTime();
		java.sql.Date sqlDate = new java.sql.Date(t);
		String rateType;
		if(exchangeRate.getRATE_TYPE().equalsIgnoreCase("M"))
		{
			rateType = "ACCT";
		}else{
			rateType = "PRCE";
		}
		SqlParameterSource paramSource = new MapSqlParameterSource()
				.addValue("exchangeRate", exchangeRate.getEXCH_RATE())
				.addValue("fromCurr", exchangeRate.getFROM_CURR())
				.addValue("rateType", rateType)
				.addValue("toCurr", exchangeRate.getTO_CURRNCY())
				.addValue("validFrom", null != convertDate(exchangeRate.getVALID_FROM()) ? convertDate(exchangeRate.getVALID_FROM()) : "")
				.addValue("createdDate", sqlDate);

		
		String sql = "Insert into TEMP_EXCHANGERATES (EXCH_RATE,FROM_CURR,RATE_TYPE,TO_CURRNCY,FROM_DATE,CREATED_DATE) "
				+ "VALUES (:exchangeRate,:fromCurr,:rateType,:toCurr,:validFrom,:createdDate)";

		int successFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(sql, paramSource);

		String updateQuery = "UPDATE S4_EXCH_RATE S4ER SET S4LP.CREATED_DATE=:createdDate, S4ER.TO_DATE = ( SELECT GLBLER.FROM_DATE -1 "
				+ "FROM TEMP_EXCHANGERATES GLBLER  WHERE (S4ER.RATE_TYPE || S4ER.FROM_CURR || S4ER.TO_CURRNCY) ="
				+ " (GLBLER.RATE_TYPE || GLBLER.FROM_CURR || GLBLER.TO_CURRNCY)and S4ER.TO_DATE is NULL) "
				+ "WHERE EXISTS (SELECT GLBLER.FROM_DATE -1   FROM TEMP_EXCHANGERATES GLBLER, S4_EXCH_RATE S4ER WHERE "
				+ "(S4ER.RATE_TYPE || S4ER.FROM_CURR || S4ER.TO_CURRNCY) =  (GLBLER.RATE_TYPE || GLBLER.FROM_CURR "
				+ "|| GLBLER.TO_CURRNCY)and S4ER.TO_DATE is NULL)";

		//truncateTable("TEMP_EXCHANGERATES");
		int updateFlag = new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(updateQuery,
				new MapSqlParameterSource());
		if (updateFlag >= 1) {
			truncateTable("TEMP_EXCHANGERATES");
		} else {

			String insertQuery = "INSERT INTO S4_EXCH_RATE SELECT RATE_TYPE, FROM_CURR, TO_CURRNCY, FROM_DATE, TO_DATE, EXCH_RATE, CREATED_DATE FROM TEMP_EXCHANGERATES";
			new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(insertQuery,
					new MapSqlParameterSource());
			truncateTable("TEMP_EXCHANGERATES");
		}

	}

	/*
	 * Method to Truncate table 
	 */
	public void truncateTable(String tableName) {
		String truncateQuery = "TRUNCATE TABLE " + tableName;
		new NamedParameterJdbcTemplate(this.jdbcTemplate.getDataSource()).update(truncateQuery,
				new MapSqlParameterSource());

	}

}
