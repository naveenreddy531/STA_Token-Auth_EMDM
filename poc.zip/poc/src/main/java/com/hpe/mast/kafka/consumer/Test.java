/*package com.hpe.mast.kafka.consumer;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.annotation.PartitionOffset;
import org.springframework.kafka.annotation.TopicPartition;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;



@Service
public class Test  implements ConsumerSeekAware  {

    private static final Logger LOG = Logger.getLogger(Test.class);
    
    private JdbcTemplate jdbcTemplate;
    
    public Test(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
//PRODUCTMATERIALMASTER_SERP_hpit-ifsl // PRICING_DETAILS_SERP_hpit
    @KafkaListener(group = "S4-MAST_hpit-ifsl",containerFactory = "kafkaListenerContainerFactory", topicPartitions =
        { @TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
                   		partitionOffsets = @PartitionOffset(partition = "0", initialOffset = "0")),
        	@TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
       		partitionOffsets = @PartitionOffset(partition = "1", initialOffset = "0")),
        	@TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
       		partitionOffsets = @PartitionOffset(partition = "2", initialOffset = "0")),
        	@TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
       		partitionOffsets = @PartitionOffset(partition = "3", initialOffset = "0")),
        	@TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
       		partitionOffsets = @PartitionOffset(partition = "4", initialOffset = "0")),
        	@TopicPartition(topic = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl" ,
       		partitionOffsets = @PartitionOffset(partition = "5", initialOffset = "0"))
              })
    public void receive(@Payload List<String> messages,@Header(KafkaHeaders.RECEIVED_PARTITION_ID) 
    List<Integer> partitions,@Header(KafkaHeaders.OFFSET) List<Long> offsets) throws ParseException {
    	
    	
    		for (int i = 0; i < messages.size(); i++) {
    			LOG.info("--MSG--"+messages.get(i));
    			
    		}

}
    
    @Override
	public void registerSeekCallback(ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onPartitionsAssigned(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 0, 0);
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 1, 0);
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 2, 0);
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 3, 0);
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 4, 0);
		callback.seek("PRODUCTMATERIALMASTER_SERP_hpit-ifsl", 5, 0);
		
	}

	@Override
	public void onIdleContainer(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}
	
	
}



*/