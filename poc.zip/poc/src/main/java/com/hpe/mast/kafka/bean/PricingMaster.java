package com.hpe.mast.kafka.bean;

import java.util.List;

public class PricingMaster {
	
	public List<PricingInformation> PricingDetails;

	public List<PricingInformation> getPricingDetails() {
		return PricingDetails;
	}

	public void setPricingDetails(List<PricingInformation> pricingDetails) {
		PricingDetails = pricingDetails;
	}

	
	
	

}
