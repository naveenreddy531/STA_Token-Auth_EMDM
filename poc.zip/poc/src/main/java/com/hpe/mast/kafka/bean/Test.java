/*package com.hpe.mast.kafka.bean;

import java.util.ArrayList;

public class Test {
	 private String SourceSystemCode;
	 private String MaterialIdentifier;
	 private String MaterialGroupCode;
	 private String BaseUnitofMeasureCode;
	 private String ExternalMaterialGroupCode;
	 private String SalesDivisionCode;
	 private String LaboratoryDesignCode;
	 private String ProductHierarchyCode;
	 private String PackagingMaterialGroupCode;
	 private String MaterialTypeCode;
	 private String IndustrySectorCode;
	 private float GrossWeight;
	 private float NetWeight;
	 private String WeightUnitofMeasureCode;
	 private float MaterialVolume;
	 private String VolumeUnitOfMeasureCode;
	 private String CrossPlantMaterialStatusCode;
	 private String CrossPlantMaterialStatusEffectiveDate;
	 private String MaterialInspectionDocumentIdentifier;
	 private String InternationalArticleNumber;
	 private String CADIndicator;
	 private String ConfigurableMaterialIndicator;
	 private String GeneralMaterialItemCategoryGroupCode;
	 private String UpdatedByUserID;
	 private String CreatedByUserID;
	 private String SourceSystemCreateTimestamp;
	 private String SourceSystemUpdateTimestamp;
	 ArrayList < Object > MaterialLanguage = new ArrayList < Object > ();
	 ArrayList < Object > MaterialUnitOfMeasure = new ArrayList < Object > ();
	 MaterialType MaterialTypeObject;
	 MaterialGroup MaterialGroupObject;
	 CrossPlantMaterialStatus CrossPlantMaterialStatusObject;
	 ProductHierarchy ProductHierarchyObject;
	 ExternalMaterialGroup ExternalMaterialGroupObject;
	 IndustrySector IndustrySectorObject;
	 LaboratoryDesign LaboratoryDesignObject;
	 PackagingMaterialGroup PackagingMaterialGroupObject;
	 SalesDivision SalesDivisionObject;
	 ArrayList < Object > UnitOfMeasure = new ArrayList < Object > ();
	 ArrayList < Object > MaterialClassAllocation = new ArrayList < Object > ();


	 // Getter Methods 

	 public String getSourceSystemCode() {
	  return SourceSystemCode;
	 }

	 public String getMaterialIdentifier() {
	  return MaterialIdentifier;
	 }

	 public String getMaterialGroupCode() {
	  return MaterialGroupCode;
	 }

	 public String getBaseUnitofMeasureCode() {
	  return BaseUnitofMeasureCode;
	 }

	 public String getExternalMaterialGroupCode() {
	  return ExternalMaterialGroupCode;
	 }

	 public String getSalesDivisionCode() {
	  return SalesDivisionCode;
	 }

	 public String getLaboratoryDesignCode() {
	  return LaboratoryDesignCode;
	 }

	 public String getProductHierarchyCode() {
	  return ProductHierarchyCode;
	 }

	 public String getPackagingMaterialGroupCode() {
	  return PackagingMaterialGroupCode;
	 }

	 public String getMaterialTypeCode() {
	  return MaterialTypeCode;
	 }

	 public String getIndustrySectorCode() {
	  return IndustrySectorCode;
	 }

	 public float getGrossWeight() {
	  return GrossWeight;
	 }

	 public float getNetWeight() {
	  return NetWeight;
	 }

	 public String getWeightUnitofMeasureCode() {
	  return WeightUnitofMeasureCode;
	 }

	 public float getMaterialVolume() {
	  return MaterialVolume;
	 }

	 public String getVolumeUnitOfMeasureCode() {
	  return VolumeUnitOfMeasureCode;
	 }

	 public String getCrossPlantMaterialStatusCode() {
	  return CrossPlantMaterialStatusCode;
	 }

	 public String getCrossPlantMaterialStatusEffectiveDate() {
	  return CrossPlantMaterialStatusEffectiveDate;
	 }

	 public String getMaterialInspectionDocumentIdentifier() {
	  return MaterialInspectionDocumentIdentifier;
	 }

	 public String getInternationalArticleNumber() {
	  return InternationalArticleNumber;
	 }

	 public String getCADIndicator() {
	  return CADIndicator;
	 }

	 public String getConfigurableMaterialIndicator() {
	  return ConfigurableMaterialIndicator;
	 }

	 public String getGeneralMaterialItemCategoryGroupCode() {
	  return GeneralMaterialItemCategoryGroupCode;
	 }

	 public String getUpdatedByUserID() {
	  return UpdatedByUserID;
	 }

	 public String getCreatedByUserID() {
	  return CreatedByUserID;
	 }

	 public String getSourceSystemCreateTimestamp() {
	  return SourceSystemCreateTimestamp;
	 }

	 public String getSourceSystemUpdateTimestamp() {
	  return SourceSystemUpdateTimestamp;
	 }

	 public MaterialType getMaterialType() {
	  return MaterialTypeObject;
	 }

	 public MaterialGroup getMaterialGroup() {
	  return MaterialGroupObject;
	 }

	 public CrossPlantMaterialStatus getCrossPlantMaterialStatus() {
	  return CrossPlantMaterialStatusObject;
	 }

	 public ProductHierarchy getProductHierarchy() {
	  return ProductHierarchyObject;
	 }

	 public ExternalMaterialGroup getExternalMaterialGroup() {
	  return ExternalMaterialGroupObject;
	 }

	 public IndustrySector getIndustrySector() {
	  return IndustrySectorObject;
	 }

	 public LaboratoryDesign getLaboratoryDesign() {
	  return LaboratoryDesignObject;
	 }

	 public PackagingMaterialGroup getPackagingMaterialGroup() {
	  return PackagingMaterialGroupObject;
	 }

	 public SalesDivision getSalesDivision() {
	  return SalesDivisionObject;
	 }

	 // Setter Methods 

	 public void setSourceSystemCode(String SourceSystemCode) {
	  this.SourceSystemCode = SourceSystemCode;
	 }

	 public void setMaterialIdentifier(String MaterialIdentifier) {
	  this.MaterialIdentifier = MaterialIdentifier;
	 }

	 public void setMaterialGroupCode(String MaterialGroupCode) {
	  this.MaterialGroupCode = MaterialGroupCode;
	 }

	 public void setBaseUnitofMeasureCode(String BaseUnitofMeasureCode) {
	  this.BaseUnitofMeasureCode = BaseUnitofMeasureCode;
	 }

	 public void setExternalMaterialGroupCode(String ExternalMaterialGroupCode) {
	  this.ExternalMaterialGroupCode = ExternalMaterialGroupCode;
	 }

	 public void setSalesDivisionCode(String SalesDivisionCode) {
	  this.SalesDivisionCode = SalesDivisionCode;
	 }

	 public void setLaboratoryDesignCode(String LaboratoryDesignCode) {
	  this.LaboratoryDesignCode = LaboratoryDesignCode;
	 }

	 public void setProductHierarchyCode(String ProductHierarchyCode) {
	  this.ProductHierarchyCode = ProductHierarchyCode;
	 }

	 public void setPackagingMaterialGroupCode(String PackagingMaterialGroupCode) {
	  this.PackagingMaterialGroupCode = PackagingMaterialGroupCode;
	 }

	 public void setMaterialTypeCode(String MaterialTypeCode) {
	  this.MaterialTypeCode = MaterialTypeCode;
	 }

	 public void setIndustrySectorCode(String IndustrySectorCode) {
	  this.IndustrySectorCode = IndustrySectorCode;
	 }

	 public void setGrossWeight(float GrossWeight) {
	  this.GrossWeight = GrossWeight;
	 }

	 public void setNetWeight(float NetWeight) {
	  this.NetWeight = NetWeight;
	 }

	 public void setWeightUnitofMeasureCode(String WeightUnitofMeasureCode) {
	  this.WeightUnitofMeasureCode = WeightUnitofMeasureCode;
	 }

	 public void setMaterialVolume(float MaterialVolume) {
	  this.MaterialVolume = MaterialVolume;
	 }

	 public void setVolumeUnitOfMeasureCode(String VolumeUnitOfMeasureCode) {
	  this.VolumeUnitOfMeasureCode = VolumeUnitOfMeasureCode;
	 }

	 public void setCrossPlantMaterialStatusCode(String CrossPlantMaterialStatusCode) {
	  this.CrossPlantMaterialStatusCode = CrossPlantMaterialStatusCode;
	 }

	 public void setCrossPlantMaterialStatusEffectiveDate(String CrossPlantMaterialStatusEffectiveDate) {
	  this.CrossPlantMaterialStatusEffectiveDate = CrossPlantMaterialStatusEffectiveDate;
	 }

	 public void setMaterialInspectionDocumentIdentifier(String MaterialInspectionDocumentIdentifier) {
	  this.MaterialInspectionDocumentIdentifier = MaterialInspectionDocumentIdentifier;
	 }

	 public void setInternationalArticleNumber(String InternationalArticleNumber) {
	  this.InternationalArticleNumber = InternationalArticleNumber;
	 }

	 public void setCADIndicator(String CADIndicator) {
	  this.CADIndicator = CADIndicator;
	 }

	 public void setConfigurableMaterialIndicator(String ConfigurableMaterialIndicator) {
	  this.ConfigurableMaterialIndicator = ConfigurableMaterialIndicator;
	 }

	 public void setGeneralMaterialItemCategoryGroupCode(String GeneralMaterialItemCategoryGroupCode) {
	  this.GeneralMaterialItemCategoryGroupCode = GeneralMaterialItemCategoryGroupCode;
	 }

	 public void setUpdatedByUserID(String UpdatedByUserID) {
	  this.UpdatedByUserID = UpdatedByUserID;
	 }

	 public void setCreatedByUserID(String CreatedByUserID) {
	  this.CreatedByUserID = CreatedByUserID;
	 }

	 public void setSourceSystemCreateTimestamp(String SourceSystemCreateTimestamp) {
	  this.SourceSystemCreateTimestamp = SourceSystemCreateTimestamp;
	 }

	 public void setSourceSystemUpdateTimestamp(String SourceSystemUpdateTimestamp) {
	  this.SourceSystemUpdateTimestamp = SourceSystemUpdateTimestamp;
	 }

	 public void setMaterialType(MaterialType MaterialTypeObject) {
	  this.MaterialTypeObject = MaterialTypeObject;
	 }

	 public void setMaterialGroup(MaterialGroup MaterialGroupObject) {
	  this.MaterialGroupObject = MaterialGroupObject;
	 }

	 public void setCrossPlantMaterialStatus(CrossPlantMaterialStatus CrossPlantMaterialStatusObject) {
	  this.CrossPlantMaterialStatusObject = CrossPlantMaterialStatusObject;
	 }

	 public void setProductHierarchy(ProductHierarchy ProductHierarchyObject) {
	  this.ProductHierarchyObject = ProductHierarchyObject;
	 }

	 public void setExternalMaterialGroup(ExternalMaterialGroup ExternalMaterialGroupObject) {
	  this.ExternalMaterialGroupObject = ExternalMaterialGroupObject;
	 }

	 public void setIndustrySector(IndustrySector IndustrySectorObject) {
	  this.IndustrySectorObject = IndustrySectorObject;
	 }

	 public void setLaboratoryDesign(LaboratoryDesign LaboratoryDesignObject) {
	  this.LaboratoryDesignObject = LaboratoryDesignObject;
	 }

	 public void setPackagingMaterialGroup(PackagingMaterialGroup PackagingMaterialGroupObject) {
	  this.PackagingMaterialGroupObject = PackagingMaterialGroupObject;
	 }

	 public void setSalesDivision(SalesDivision SalesDivisionObject) {
	  this.SalesDivisionObject = SalesDivisionObject;
	 }
	}


	
	
	
	
	
	
	
	
	
*/