package com.hpe.mast.kafka.bean;

import java.util.List;

public class ExchangeRateMaster {
	
	List<ExchangeRate> E1BP1093_0;

	public List<ExchangeRate> getE1BP1093_0() {
		return E1BP1093_0;
	}

	public void setE1BP1093_0(List<ExchangeRate> e1bp1093_0) {
		E1BP1093_0 = e1bp1093_0;
	}
	
	

}
