package com.hpe.mast.kafka.consumer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.kafka.common.TopicPartition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.listener.ConsumerSeekAware;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.hpe.mast.kafka.bean.MaterialMaster;
import com.hpe.mast.kafka.bean.PartitionOffsetBean;

@Service
@PropertySource({ "classpath:application.properties" })
public class ProductHierarchyListener implements ConsumerSeekAware {

	private static final Logger LOG = LoggerFactory.getLogger(ProductHierarchyListener.class);

	@Autowired
	MastDBDao mastDBDao;

	@Value("${productHierarchy}")
	private String topicName;

	@KafkaListener(group = "S4-MAST_hpit-ifsl_group", topics = "PRODUCTMATERIALMASTER_SERP_hpit-ifsl", containerFactory = "kafkaListenerContainerFactory")
	public void receive3(@Payload List<MaterialMaster> messages,
			@Header(KafkaHeaders.RECEIVED_PARTITION_ID) List<Integer> partitions,
			@Header(KafkaHeaders.OFFSET) List<Long> offsets, @Header(KafkaHeaders.RECEIVED_TOPIC) List<String> topics,
			Acknowledgment acknowledgment) throws ParseException {
		// List<MaterialMaster> productMaterialList = new ArrayList<>();
		//https://kafka-admin-api-itg-lb.itcs.hpecorp.net/clusters/ITG-01/topics/COGRP6_SERP_hpit-ifsl/usage
		LOG.info("---******---PRODUCT HIERARCHY TOPIC STARTED---******---");
		
		for (int i = 0; i < messages.size(); i++) {
			PartitionOffsetBean partitionData = new PartitionOffsetBean();
			MaterialMaster materialMaster = messages.get(i);

			try {
				if (null != messages.get(i).getMaterialIdentifier() && null != messages.get(i).getSourceSystemCode()
						&& null != messages.get(i).getProductHierarchyCode()
						//&& 0 != messages.get(i).getSourceSystemCreateTimestamp()
						//&& 0 != messages.get(i).getSourceSystemUpdateTimestamp()
						&& null != messages.get(i).getProductHierarchy() && null != messages.get(i).getSalesDivision()
						&& null != messages.get(i).getMaterialLanguage()) {
					if (null != messages.get(i).getProductHierarchy().getSourceSystemCode()
							&& null != messages.get(i).getProductHierarchy().getProductHierarchyCode() &&
							// null !=
							// messages.get(i).getProductHierarchy().getProductHierarchyLevelNumber()
							// &&
							null != messages.get(i).getProductHierarchy().getProductTypeCode()
							&& null != messages.get(i).getProductHierarchy().getProductFamilyCode()
							&& null != messages.get(i).getProductHierarchy().getProductCategoryCode()
							&& null != messages.get(i).getProductHierarchy().getProductSubCategoryCode()
							&& null != messages.get(i).getProductHierarchy().getProductFamilyCode()
							&& null != messages.get(i).getProductHierarchy().getProductSeriesCode()
							&& null != messages.get(i).getProductHierarchy().getProductModelCode()) {
						if(null != messages.get(i).getCrossPlantMaterialStatus()){
						materialMaster = messages.get(i);
						mastDBDao.saveProdHierarchyBatch(materialMaster);
						}
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
				LOG.info("---EXCEPTION WHILE FORMING EPRODUCT-HIERARCHY OBJECT FROM JSON RESPONSE---");
			}
			// acknowledgment.acknowledge();
			// partitionData.setTopic(topics.get(i));
			partitionData.setTopic(topicName);
			partitionData.setPartition(partitions.get(i));
			partitionData.setOffset(offsets.get(i));
			String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
			partitionData.setUpdatedTime(timeStamp);
			mastDBDao.saveOffsetData(partitionData);
		}
		LOG.info("---PRODUCT-HIERARCHY CONSUMER END---");
	}

	@Override
	public void registerSeekCallback(ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onPartitionsAssigned(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		try {
			List<PartitionOffsetBean> partitionOffsetList = mastDBDao.fetchOffsetData(topicName);
			if (partitionOffsetList == null || partitionOffsetList.size() <= 0) {
				Set<TopicPartition> topicInitialData = assignments.keySet();
				Iterator<TopicPartition> it = topicInitialData.iterator();
				while (it.hasNext()) {
					TopicPartition topic = it.next();
					callback.seek(topic.topic(), topic.partition(), 0);
				}
			} 
			else {
				Map<Integer, TopicPartition> partitionFound = new HashMap<Integer, TopicPartition>();
				Set<TopicPartition> topicInitialData = assignments.keySet();
				for (int i = 0; i < partitionOffsetList.size(); i++) {
					Iterator<TopicPartition> it = topicInitialData.iterator();
					while (it.hasNext()) {
						TopicPartition topic = it.next();
						if (partitionOffsetList.get(i).getPartition() == topic.partition()) {
							callback.seek(topicName, partitionOffsetList.get(i).getPartition(),
									partitionOffsetList.get(i).getOffset());
							LOG.info("---PARTITION(S) ASSIGNED FOR 'PROD_HIER' FROM DATABASE ---" + partitionOffsetList.get(i).getPartition());
							partitionFound.put(topic.partition(), topic);
						}
						 
					}
				}
				Iterator<TopicPartition> it2 = topicInitialData.iterator();
				while (it2.hasNext()) {
					TopicPartition topic = it2.next();
					if(!partitionFound.containsKey(topic.partition())){
						callback.seek(topic.topic(), topic.partition(), 0);
						LOG.info("---PARTITION(S) ASSIGNED FOR 'PROD_HIER' FROM S4---" +topic.partition());
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOG.info("--+++--'PROD_HIER' PARTITION ASSIGNMENT FAILED--+++--");
		}
	}

	@Override
	public void onIdleContainer(Map<org.apache.kafka.common.TopicPartition, Long> assignments,
			ConsumerSeekCallback callback) {
		// TODO Auto-generated method stub
	}

}
