package com.hpe.mast.kafka.bean;

import java.sql.Date;
import java.util.List;

public class PricingInformation {
	
	public String ListPriceValidFromDate;
	public String ListPriceValidtoDate;
	public String CurrencyCode="";
	public String CountryCode="";
	public String Incotermscode="";
	public String MCCMaterial="";
	public String AvailableMaterialIdentifier;
	public String OptionID="";
	public String PriceListTypeCode="";
	public String PriceGeo="";
	public List<ListInfo> PricingConditionItem;
	
	
	public String getListPriceValidFromDate() {
		return ListPriceValidFromDate;
	}
	public void setListPriceValidFromDate(String listPriceValidFromDate) {
		ListPriceValidFromDate = listPriceValidFromDate;
	}
	public String getListPriceValidtoDate() {
		return ListPriceValidtoDate;
	}
	public void setListPriceValidtoDate(String listPriceValidtoDate) {
		ListPriceValidtoDate = listPriceValidtoDate;
	}
	public String getCurrencyCode() {
		return CurrencyCode;
	}
	public void setCurrencyCode(String currencyCode) {
		CurrencyCode = currencyCode;
	}
	public String getCountryCode() {
		return CountryCode;
	}
	public void setCountryCode(String countryCode) {
		CountryCode = countryCode;
	}
	public String getIncotermscode() {
		return Incotermscode;
	}
	public void setIncotermscode(String incotermscode) {
		Incotermscode = incotermscode;
	}
	public String getMCCMaterial() {
		return MCCMaterial;
	}
	public void setMCCMaterial(String mCCMaterial) {
		MCCMaterial = mCCMaterial;
	}
	public String getAvailableMaterialIdentifier() {
		return AvailableMaterialIdentifier;
	}
	public void setAvailableMaterialIdentifier(String availableMaterialIdentifier) {
		AvailableMaterialIdentifier = availableMaterialIdentifier;
	}
	public String getOptionID() {
		return OptionID;
	}
	public void setOptionID(String optionID) {
		OptionID = optionID;
	}
	public String getPriceListTypeCode() {
		return PriceListTypeCode;
	}
	public void setPriceListTypeCode(String priceListTypeCode) {
		PriceListTypeCode = priceListTypeCode;
	}
	public String getPriceGeo() {
		return PriceGeo;
	}
	public void setPriceGeo(String priceGeo) {
		PriceGeo = priceGeo;
	}
	public List<ListInfo> getPricingConditionItem() {
		return PricingConditionItem;
	}
	public void setPricingConditionItem(List<ListInfo> pricingConditionItem) {
		PricingConditionItem = pricingConditionItem;
	}
	
	


}
